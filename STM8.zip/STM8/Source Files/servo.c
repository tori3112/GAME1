#include "servo.h"

/// @brief move the disc dispensing servo motor in steps, so the disc doesnt fly out too quick
void move_servo_0() {
	uint16_t TIM2_Pulse;
	GPIO_WriteLow(GPIOB, GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2);
	//test
	TIM2_Pulse = 2800;
	TIM2->CCR1H = (uint8_t)(TIM2_Pulse >> 8);
  TIM2->CCR1L = (uint8_t)(TIM2_Pulse);
	delay(500);
	//test	
	TIM2_Pulse = 3050;
	TIM2->CCR1H = (uint8_t)(TIM2_Pulse >> 8);
  TIM2->CCR1L = (uint8_t)(TIM2_Pulse);
	delay(500);
	//test
	TIM2_Pulse = 3300;
	TIM2->CCR1H = (uint8_t)(TIM2_Pulse >> 8);
  TIM2->CCR1L = (uint8_t)(TIM2_Pulse);
	delay(1000);
	TIM2_Pulse = 1800;
	TIM2->CCR1H = (uint8_t)(TIM2_Pulse >> 8);
  TIM2->CCR1L = (uint8_t)(TIM2_Pulse);
	delay(2000);
}

/// @brief close the servo motor of column one 
void close_servo_1() {
	uint16_t TIM2_Pulse;
	GPIO_WriteLow(GPIOB, GPIO_PIN_1 | GPIO_PIN_2);
	GPIO_WriteHigh(GPIOB, GPIO_PIN_0);
	TIM2_Pulse = 4000;
	TIM2->CCR1H = (uint8_t)(TIM2_Pulse >> 8);
  TIM2->CCR1L = (uint8_t)(TIM2_Pulse);
}

/// @brief open the servo motor of column one
void open_servo_1() {
	uint16_t TIM2_Pulse;
	GPIO_WriteLow(GPIOB, GPIO_PIN_1 | GPIO_PIN_2);
	GPIO_WriteHigh(GPIOB, GPIO_PIN_0);
	TIM2_Pulse = 2000;
	TIM2->CCR1H = (uint8_t)(TIM2_Pulse >> 8);
  TIM2->CCR1L = (uint8_t)(TIM2_Pulse);
}

/// @brief close the servo motor of column two
void close_servo_2() {
	uint16_t TIM2_Pulse;
	GPIO_WriteLow(GPIOB, GPIO_PIN_0 | GPIO_PIN_2);
	GPIO_WriteHigh(GPIOB, GPIO_PIN_1);
	TIM2_Pulse = 4000;
	TIM2->CCR1H = (uint8_t)(TIM2_Pulse >> 8);
  TIM2->CCR1L = (uint8_t)(TIM2_Pulse);
}

/// @brief open the servo motor of column two
void open_servo_2() {
	uint16_t TIM2_Pulse;
	GPIO_WriteLow(GPIOB, GPIO_PIN_0 | GPIO_PIN_2);
	GPIO_WriteHigh(GPIOB, GPIO_PIN_1);
	TIM2_Pulse = 2000;
	TIM2->CCR1H = (uint8_t)(TIM2_Pulse >> 8);
  TIM2->CCR1L = (uint8_t)(TIM2_Pulse);
}

/// @brief close the servo motor of column three
void close_servo_3() {
	uint16_t TIM2_Pulse;
	GPIO_WriteHigh(GPIOB, GPIO_PIN_0 | GPIO_PIN_1);
	GPIO_WriteLow(GPIOB, GPIO_PIN_2);
	TIM2_Pulse = 4000;
	TIM2->CCR1H = (uint8_t)(TIM2_Pulse >> 8);
  TIM2->CCR1L = (uint8_t)(TIM2_Pulse);
}

/// @brief open the servo motor of column three
void open_servo_3() {
	uint16_t TIM2_Pulse;
	GPIO_WriteHigh(GPIOB, GPIO_PIN_0 | GPIO_PIN_1);
	GPIO_WriteLow(GPIOB, GPIO_PIN_2);
	TIM2_Pulse = 2000;
	TIM2->CCR1H = (uint8_t)(TIM2_Pulse >> 8);
  TIM2->CCR1L = (uint8_t)(TIM2_Pulse);
}

/// @brief close the servo motor of column four
void close_servo_4() {
	uint16_t TIM2_Pulse;
	GPIO_WriteLow(GPIOB, GPIO_PIN_0 | GPIO_PIN_1);
	GPIO_WriteHigh(GPIOB, GPIO_PIN_2);
	TIM2_Pulse = 4000;
	TIM2->CCR1H = (uint8_t)(TIM2_Pulse >> 8);
  TIM2->CCR1L = (uint8_t)(TIM2_Pulse);
}

/// @brief open the servo motor of column four
void open_servo_4() {
	uint16_t TIM2_Pulse;
	GPIO_WriteLow(GPIOB, GPIO_PIN_0 | GPIO_PIN_1);
	GPIO_WriteHigh(GPIOB, GPIO_PIN_2);
	TIM2_Pulse = 2000;
	TIM2->CCR1H = (uint8_t)(TIM2_Pulse >> 8);
  TIM2->CCR1L = (uint8_t)(TIM2_Pulse);
}

/// @brief close the servo motor of column five
void close_servo_5() {
	uint16_t TIM2_Pulse;
	GPIO_WriteLow(GPIOB, GPIO_PIN_1);
	GPIO_WriteHigh(GPIOB, GPIO_PIN_0 | GPIO_PIN_2);
	TIM2_Pulse = 4000;
	TIM2->CCR1H = (uint8_t)(TIM2_Pulse >> 8);
  TIM2->CCR1L = (uint8_t)(TIM2_Pulse);
}

/// @brief open the servo motor of column five
void open_servo_5() {
	uint16_t TIM2_Pulse;
	GPIO_WriteLow(GPIOB, GPIO_PIN_1);
	GPIO_WriteHigh(GPIOB, GPIO_PIN_0 | GPIO_PIN_2);
	TIM2_Pulse = 2000;
	TIM2->CCR1H = (uint8_t)(TIM2_Pulse >> 8);
  TIM2->CCR1L = (uint8_t)(TIM2_Pulse);
}

/// @brief close the servo motor of column six
void close_servo_6() {
	uint16_t TIM2_Pulse;
	GPIO_WriteLow(GPIOB, GPIO_PIN_0);
	GPIO_WriteHigh(GPIOB, GPIO_PIN_1 | GPIO_PIN_2);
	TIM2_Pulse = 4000;
	TIM2->CCR1H = (uint8_t)(TIM2_Pulse >> 8);
  TIM2->CCR1L = (uint8_t)(TIM2_Pulse);
}

/// @brief open the servo motor of column six
void open_servo_6() {
	uint16_t TIM2_Pulse;
	GPIO_WriteLow(GPIOB, GPIO_PIN_0);
	GPIO_WriteHigh(GPIOB, GPIO_PIN_1 | GPIO_PIN_2);
	TIM2_Pulse = 2000;
	TIM2->CCR1H = (uint8_t)(TIM2_Pulse >> 8);
  TIM2->CCR1L = (uint8_t)(TIM2_Pulse);
}

/// @brief close the servo motor of column seven
void close_servo_7() {
	uint16_t TIM2_Pulse;
	GPIO_WriteHigh(GPIOB,GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2);
	TIM2_Pulse = 4000;
	TIM2->CCR1H = (uint8_t)(TIM2_Pulse >> 8);
  TIM2->CCR1L = (uint8_t)(TIM2_Pulse);
}

/// @brief open the servo motor of column one
void open_servo_7() {
	uint16_t TIM2_Pulse;
	GPIO_WriteHigh(GPIOB,GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2);
	TIM2_Pulse = 2000;
	TIM2->CCR1H = (uint8_t)(TIM2_Pulse >> 8);
  TIM2->CCR1L = (uint8_t)(TIM2_Pulse);
}

/// @brief open the servo motors of all columns
void open_all(){
	open_servo_1();
	delay(300);
	open_servo_2();
	delay(300);
	open_servo_3();
	delay(300);
	open_servo_4();
	delay(300);
	open_servo_5();
	delay(300);
	open_servo_6();
	delay(300);
	open_servo_7();
	delay(300);
}

/// @brief close the servo motors of all columns
void close_all(){
	close_servo_1();
	delay(300);
	close_servo_2();
	delay(300);
	close_servo_3();
	delay(300);
	close_servo_4();
	delay(300);
	close_servo_5();
	delay(300);
	close_servo_6();
	delay(300);
	close_servo_7();
	delay(300);
}


/// @brief delay to put between opening and closing columns
/// @param milliseconds approximate delay time in milliseconds(empirically determined) 
void delay(int milliseconds) {
	int i;
	while(milliseconds--) {
		for(i = 0; i < 400; i++) {
		}
	}
}
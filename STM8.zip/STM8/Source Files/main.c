/**
  ******************************************************************************
  * @file    Project/main.c 
  * @author  MCD Application Team
  * @version V2.3.0
  * @date    16-June-2017
  * @brief   Main program body
   ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2014 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software 
  * distributed under the License is distributed on an "AS IS" BASIS, 
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
*/ 

/* Includes ------------------------------------------------------------------*/
#include "stm8s.h"
#include "mirf.h"
#include "servo.h"

/* Private defines -----------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
void init(void);
void main(void);
void IO_init(void);
void PWM_init(void);
void interrupts_init(void);

void make_move(uint8_t column_nr);
/* Variables -----------------------------------------------------------------*/
bool PTX;
int ret; 
uint8_t column;
char payload[4]; 

/* Private functions ---------------------------------------------------------*/

void init(){
	IO_init();
	PWM_init();
	interrupts_init();
	open_all();
	delay(200);

	// Initialization for receiver
	Nrf24_init();
	PTX = 0;
	Nrf24_config(&PTX);
	
	// Set receiver address
	ret = Nrf24_setRADDR((uint8_t *)"ABCDE");
	
	// Set speed 1Mbps
	Nrf24_SetSpeedDataRates(RF24_1MBPS);

	// Clear RX FIFO
	Nrf24_flushRx();
	
}

void main(){
  init();
	while (1) {
		if (Nrf24_dataReady()) {
			Nrf24_getData(payload);
			column = payload[0];
			if(column <= 7 && column > 0) {
				close_all();
				delay(300);
				make_move(column);
				delay(300);
				open_all();
			}
		}
	}
} 

void IO_init(){	
	GPIO_Init(GPIOD, GPIO_PIN_4, GPIO_MODE_OUT_PP_HIGH_FAST);
	GPIO_Init(GPIOB, GPIO_PIN_3, GPIO_MODE_IN_PU_IT);
	GPIO_Init(GPIOB, GPIO_PIN_0, GPIO_MODE_OUT_PP_HIGH_FAST);
	GPIO_Init(GPIOB, GPIO_PIN_1, GPIO_MODE_OUT_PP_HIGH_FAST);
	GPIO_Init(GPIOB ,GPIO_PIN_2, GPIO_MODE_OUT_PP_HIGH_FAST);
}

void PWM_init(){
    TIM2_TimeBaseInit(TIM2_PRESCALER_1, 40000);
    TIM2_OC1Init(TIM2_OCMODE_PWM1,
                 TIM2_OUTPUTSTATE_ENABLE,
                 2000,
                 TIM2_OCPOLARITY_HIGH); 
    TIM2_Cmd(ENABLE);
}

void interrupts_init(){
	enableInterrupts();
}

/// @param column_nr an integer with the number of the servo motor that needs to open
void make_move(uint8_t column_nr){	
	switch(column_nr){
		case 1: 
			open_servo_1();
			delay(1000);
			move_servo_0();
			delay(100);
			break;
		case 2: 
			open_servo_2();
			delay(1000);
			move_servo_0();
			delay(100);
			break;
		case 3: 
			open_servo_3();
			delay(1000);
			move_servo_0();
			delay(100);
			break;
		case 4: 
			open_servo_4();
			delay(1000);
			move_servo_0();
			delay(100);
			break;
		case 5: 
			open_servo_5();
			delay(1000);
			move_servo_0();
			delay(100);
			break;
		case 6: 
			open_servo_6();
			delay(1000);
			move_servo_0();
			delay(100);
			break;
		case 7: 
			open_servo_7();
			delay(1000);
			move_servo_0();
			delay(100);
			break;
	}
}

#ifdef USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *   where the assert_param error has occurred.
  * @param file: pointer to the source file name
  * @param line: assert_param error line source number
  * @retval : None
  */
void assert_failed(u8* file, u32 line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif


/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/

#include "stm8s.h"
#ifndef SERVO_H
#define SERVO_H

void move_servo_0(void);
void open_servo_1(void);
void close_servo_1(void);
void open_servo_2(void);
void close_servo_2(void);
void open_servo_3(void);
void close_servo_3(void);
void open_servo_4(void);
void close_servo_4(void);
void open_servo_5(void);
void close_servo_5(void);
void open_servo_6(void);
void close_servo_6(void);
void open_servo_7(void);
void close_servo_7(void);
void open_all(void);
void close_all(void);
void delay(int);

#endif